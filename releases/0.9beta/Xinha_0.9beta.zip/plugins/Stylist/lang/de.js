// I18N constants
// LANG: "de", ENCODING: UTF-8
// Author: Mihai Bazon, http://dynarch.com/mishoo
{
  "Styles": "Stile"
};
