﻿// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "language select": "Sélection de la langue",
  "&mdash; language &mdash;":	"&mdash; Langue &mdash;",
  "Greek": "grec",
  "English": "anglais",
  "French": "français",
  "Latin": "latin"
};