// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Name/ID:": "Nom/ID",
  "Insert scrolling marquee": "Insérer marquee défilant",
  "Insert marquee": "Insérer marquee",
  "Direction:": "Direction",
  "Behavior:": "Comportement",
  "Text:": "Texte",
  "Background-Color:": "Couleur de fond",
  "Width:": "Largeur",
  "Height:": "Hauteur",
  "Speed Control": "Controle de vitesse",
  "Scroll Amount:": "Quantité de défilement",
  "Scroll Delay:": "Délai du défilement",
  "Cancel": "Annuler"
};