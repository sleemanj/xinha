// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{ 
  "Name/ID:": "Navn/ID:",
  "Insert scrolling marquee": "Sett inn rulletekst",
  "Insert marquee": "Sett inn rulletekst",	
  "Direction:": "Rettning:",
  "Behavior:": "Oppførsel:",
  "Text:": "Tekst:",
  "Background-Color:": "Bakgrunnsfarge:",
  "Width:": "Bredde:",
  "Height:": "Høyde:",
  "Speed Control": "Egenskaper for hastigheten til rulleteksten",
  "Scroll Amount:": "Hastighet:",
  "Scroll Delay:": "Forsinkelse:",
  "Cancel": "Avbryt"
};