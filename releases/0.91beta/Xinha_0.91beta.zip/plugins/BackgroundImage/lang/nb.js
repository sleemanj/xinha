// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Set page background image": "Velg bakgrunnsbilde på siden",
  "Set Page Background Image": "Velg bakgrunnsbilde på Siden",
  "Remove Current Background": "Fjern gjeldende bakgrunn",
  "Cancel": "Avbryt"
};