// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Insert Anchor": "Insérer une ancre",
  "Anchor name": "Nom de l'ancre",
  "Delete": "Supprimer"
};