// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Decimal numbers": "Desimaltall",
  "Lower roman numbers": "Lower roman numbers",
  "Upper roman numbers": "Upper roman numbers",
  "Lower latin letters": "Lower latin letters",
  "Upper latin letters": "Upper latin letters",
  "Lower greek letters": "Lower greek letters",
  "Choose list style type (for ordered lists)": "Velg listetype (for nummererte lister)"
};
