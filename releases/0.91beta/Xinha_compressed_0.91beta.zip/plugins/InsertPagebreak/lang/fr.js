// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Page break": "Séparateur de page"
};