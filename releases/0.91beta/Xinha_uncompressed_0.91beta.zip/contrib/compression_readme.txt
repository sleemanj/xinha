You can use the compress.bat to compress JavaScript files by drag&drop in Windows.

Please be aware that the language files cannot be compressed.

If you want the original files to be kept, open compress.bat and remvove the # in the line
# FOR %%V IN (%*) DO del %%V_uncompressed.js