// I18N constants
// LANG: "de", ENCODING: UTF-8 | ISO-8859-1
// Author: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
	"Insert template"          : "Template einfügen",
	"Cancel"                   : "Abbrechen"
};