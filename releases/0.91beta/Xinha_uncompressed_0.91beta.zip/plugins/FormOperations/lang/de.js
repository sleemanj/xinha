// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "Insert a Form.": "Email Form einfügen.",
  "Insert a text, password or hidden field.": "Passwort oder unsichtbares Feld einfügen.",
  "Insert a multi-line text field.": "Mehrzeiliges Textfeld einfügen.",
  "Insert a select field.": "Auswahlfeld einfügen.",
  "Insert a check box.": "Häkchenfeld einfügen",
  "Insert a radio button.": "Optionsfeld einfügen",
  "Insert a submit/reset button.": "Senden/zurücksetzen Schaltfläche"
};
