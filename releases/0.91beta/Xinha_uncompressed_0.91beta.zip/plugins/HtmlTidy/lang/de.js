// I18N constants
// LANG: "de", ENCODING: UTF-8
// Author: Raimund Meyer ray@ray-of-light.org
{
  "HTML Tidy": "HTML Tidy",
	"Tidy failed.  Check your HTML for syntax errors.": "Tidy fehlgeschlagen. Prüfen Sie den HTML Code nach Syntax-Fehlern."  
};
