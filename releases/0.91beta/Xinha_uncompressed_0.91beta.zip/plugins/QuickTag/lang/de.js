// I18N constants
// LANG: "de", ENCODING: UTF-8
{ 
  "Quick Tag Editor": "Quick TAG Editor",
  "Enter the TAG you want to insert": "Enter the TAG you want to insert",
  "You have to select some text": "You have to select some text",
  "There are some unclosed quote": "There are some unclosed quote",
  "This attribute already exists in the TAG": "This attribute already exists in the TAG",
  "No CSS class avaiable": "No CSS classes avaiable",
  "OPTIONS": "OPTIONS",
  "ATTRIBUTES": "ATTRIBUTES",
  "TAGs": "TAGs",
  "Colors": "Colors",
  "Ok": "Ok",
  "Cancel": "Cancel"
};
