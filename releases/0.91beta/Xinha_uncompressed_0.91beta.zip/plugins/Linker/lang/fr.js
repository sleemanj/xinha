// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "You must select some text before making a new link.": "Vous devez sélectionner un texte avant de créer un nouveau lien",
  "Are you sure you wish to remove this link?": "Confirmez-vous la suppression de ce lien ?",
  "REMOVE LINK": "Supprimer",
  "CANCEL": "Annuler",
  "URL Link": "Lien URL",
  "Ordinary Link": "Lien standard",
  "Same Window (jump out of frames)": "Même fenêtre (sort des frames)",
  "New Window": "Nouvelle fenêtre",
  "Popup Window": "Fenêtre popup",
  "Email Link": "Lien email",
  "Email Address:": "Adresse email",
  "Subject:": "Sujet",
  "Message Template:": "Message",
  "Size:": "Taille",
  "Name:": "Nom"
};