// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Insert template": "Insérer un template",
  "Cancel": "Annulation"
};