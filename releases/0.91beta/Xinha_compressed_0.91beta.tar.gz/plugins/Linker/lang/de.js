// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "You must select some text before making a new link.": "Sie müssen einen Text markieren um einen Link zu erstellen",
  "Are you sure you wish to remove this link?": "Wollen Sie diesen Link wirklich entfernen?",
  "REMOVE LINK": "LINK ENTFERNEN",
  "CANCEL": "ABBRECHEN",
  "URL Link": "URL Adresse",
  "Ordinary Link": "Standard Link",
  "Same Window (jump out of frames)": "Selbes Fenster (ganzer Bereich)",
  "New Window": "Neues Fenster",
  "Popup Window": "Pop-Up Fenster",
  "Email Link": "Email Link",
  "Email Address:": "Email Adresse",
  "Subject:": "Betreff:",
  "Message Template:": "Nachrichten Vorlage:",
  "Size:": "Größe:",
  "Name:": "Name:"
};