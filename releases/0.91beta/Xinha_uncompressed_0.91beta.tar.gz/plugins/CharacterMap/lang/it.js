// I18N constants
// LANG: "it", ENCODING: UTF-8
{
  "Insert special character": "Inserisca il carattere speciale",
  "Cancel": "Annullamento"
};
