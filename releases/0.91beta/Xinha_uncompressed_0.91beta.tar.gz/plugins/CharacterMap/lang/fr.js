// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Insert special character": "Insérer caractère spécial",
  "Cancel": "Annuler"
};