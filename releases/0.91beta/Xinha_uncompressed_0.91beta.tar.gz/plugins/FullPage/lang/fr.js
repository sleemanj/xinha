// I18N for the FullPage plugin
// LANG: "fr", ENCODING: UTF-8
{
  "Alternate style-sheet:": "Feuille CSS alternative",
  "Background color:": "Couleur d'arrière plan",
  "Cancel": "Annuler",
  "DOCTYPE:": "DOCTYPE",
  "Document properties": "Propriétés du document",
  "Document title:": "Titre du document",
  "OK": "OK",
  "Primary style-sheet:": "Feuille CSS primaire",
  "Text color:": "Couleur de texte",
  "Character set:": "Jeu de caractères",
  "Description:": "Description",
  "Keywords:": "Mots clés",
  "UTF-8 (recommended)": "UTF-8 (recommandé)"
};