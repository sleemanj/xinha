// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Edit HTML for selected text": "Rediger HTML for den valgte teksten"
};