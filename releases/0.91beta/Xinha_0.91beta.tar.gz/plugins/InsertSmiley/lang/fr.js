// I18N constants
// LANG: "fr", ENCODING: UTF-8
{ 
	"Insert Smiley": "Insérer un smiley",
	"Smiley": "Smiley",
	"Cancel": "Annuler"
};