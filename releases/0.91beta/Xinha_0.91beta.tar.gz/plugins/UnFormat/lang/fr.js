// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Page Cleaner": "Nettoyeur de page",
  "Cleaning Area": "Zone de nettoyage",
  "Selection": "Sélection",
  "All": "Tout",
  "Cleaning options": "Options de nettoyage",
  "Formatting:": "Format",
  "All HTML:": "Tout le HTML",
  "Select which types of formatting you would like to remove.": "Sélectionnez quel type de formatage vous voulez supprimer."
};