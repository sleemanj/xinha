// I18N constants
// LANG: "de", ENCODING: UTF-8
// Author: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "Set page background image": "Seiten-Hintergrundbild setzen",
  "Set Page Background Image": "Seiten-Hintergrundbild setzen",
  "Remove Current Background": "Aktuellen Hintergrund entfernen",
  "Cancel": "Abbrechen"
};
